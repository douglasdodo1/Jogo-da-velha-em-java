package jogodavelha;

/**
 *
 * @author carva
 */
public class Vitoria {
    private int w1 = 0;
    private int w2 = 0;
    private int w3 = 0;
    private int w4 = 0;
    private int w5 = 0;
    private int w6 = 0;
    private int w7 = 0;
    private int w8 = 0;
    private int w9 = 0;
    private Boolean stop = false;
    private Boolean loose = false;
    private int vitoria = 0;
    private int derrota = 0;
    private Boolean perdeu = false;
    
    public void setWp(int p){
        switch(p){
            case 1:
            this.setW1(1);
            break;
            case 2:
            this.setW2(1);
            break;
            case 3:
            this.setW3(1);
            break;
            case 4:
            this.setW4(1);
            break;
            case 5:
            this.setW5(1);
            break;
            case 6:
            this.setW6(1);
            break;
            case 7:
            this.setW7(1);
            break;
            case 8:
            this.setW8(1);
            break;
            case 9:
            this.setW9(1);
            break;
            
            
            
        }
    }
    
    public void setWm(int m){
        switch(m){
            case 1:
            this.setW1(2);
            break;
            case 2:
            this.setW2(2);
            break;
            case 3:
            this.setW3(2);
            break;
            case 4:
            this.setW4(2);
            break;
            case 5:
            this.setW5(2);
            break;
            case 6:
            this.setW6(2);
            break;
            case 7:
            this.setW7(2);
            break;
            case 8:
            this.setW8(2);
            break;
            case 9:
            this.setW9(2);
            break;
            
            
            
        }
    }
    
    public void reset(){
        this.setW1(0);
        this.setW2(0);
        this.setW3(0);
        this.setW4(0);
        this.setW5(0);
        this.setW6(0);
        this.setW7(0);
        this.setW8(0);
        this.setW9(0);
        
    }
    
    public void status(){
        System.out.println(w1);
        System.out.println(w2);
        System.out.println(w3);
        System.out.println(w4);
        System.out.println(w5);
        System.out.println(w6);
        System.out.println(w7);
        System.out.println(w8);
        System.out.println(w9);
    }
    
    public  void getWc(){
      if(this.getW1()==1&&this.getW2()==1&&this.getW3()==1){
          this.setStop(true);
          System.out.println("vitoria do jogador");  
          this.setVitoria(this.getVitoria()+1);
    }
       if(this.getW1()==2&&this.getW2()==2&&this.getW3()==2){
           loose = true;
           System.out.println("vitoria do computador");
           this.setDerrota(this.getDerrota()+1);
           this.setPerdeu(true);
           
           
    }
        if(this.getW4()==1&&this.getW5()==1&&this.getW6()==1){
          this.setStop(true);
          System.out.println("vitoria do jogador");  
          this.setVitoria(this.getVitoria()+1);
    }
       if(this.getW4()==2&&this.getW5()==2&&this.getW6()==2){
           loose = true;
           System.out.println("vitoria do computador");
           this.setDerrota(this.getDerrota()+1);
           this.setPerdeu(true);
    }
       if(this.getW7()==1&&this.getW8()==1&&this.getW9()==1){
          this.setStop(true);
          System.out.println("vitoria do jogador");  
          this.setVitoria(this.getVitoria()+1);
    }
       if(this.getW7()==2&&this.getW8()==2&&this.getW9()==2){
           loose = true;
           System.out.println("vitoria do computador");
           this.setDerrota(this.getDerrota()+1);
           this.setPerdeu(true);
    }
        if(this.getW1()==1&&this.getW4()==1&&this.getW7()==1){
          this.setStop(true);
          System.out.println("vitoria do jogador");  
          this.setVitoria(this.getVitoria()+1);
    }
       if(this.getW1()==2&&this.getW4()==2&&this.getW7()==2){
           loose = true;
           System.out.println("vitoria do computador");
           this.setDerrota(this.getDerrota()+1);
           this.setPerdeu(true);
    }
        if(this.getW2()==1&&this.getW5()==1&&this.getW8()==1){
          this.setStop(true);
          System.out.println("vitoria do jogador");  
          this.setVitoria(this.getVitoria()+1);
    }
       if(this.getW2()==2&&this.getW5()==2&&this.getW8()==2){
           loose = true;
           System.out.println("vitoria do computador");
           this.setDerrota(this.getDerrota()+1);
           this.setPerdeu(true);
    }
        if(this.getW3()==1&&this.getW6()==1&&this.getW9()==1){
          this.setStop(true);
          System.out.println("vitoria do jogador");  
          this.setVitoria(this.getVitoria()+1);
    }
       if(this.getW3()==2&&this.getW6()==2&&this.getW9()==2){
           loose = true;
           System.out.println("vitoria do computador");
           this.setDerrota(this.getDerrota()+1);
           this.setPerdeu(true);
    }
          if(this.getW1()==1&&this.getW5()==1&&this.getW9()==1){
          this.setStop(true);
          System.out.println("vitoria do jogador");  
          this.setVitoria(this.getVitoria()+1);
    }
       if(this.getW1()==2&&this.getW5()==2&&this.getW9()==2){
           loose = true;
           System.out.println("vitoria do computador");
           this.setDerrota(this.getDerrota()+1);
           this.setPerdeu(true);
       }
       if(this.getW3()==1&&this.getW5()==1&&this.getW7()==1){
          this.setStop(true);
          System.out.println("vitoria do jogador");  
          this.setVitoria(this.getVitoria()+1);
    }
       if(this.getW3()==2&&this.getW5()==2&&this.getW7()==2){
           loose = true;
           System.out.println("vitoria do computador");
           this.setDerrota(this.getDerrota()+1);
           this.setPerdeu(true);
       }
       
    }

    public Boolean getPerdeu() {
        return perdeu;
    }

    public void setPerdeu(Boolean perdeu) {
        this.perdeu = perdeu;
    }

    public Boolean getLoose() {
        return loose;
    }

    public void setLoose(Boolean loose) {
        this.loose = loose;
    }
    
    
    public int getW1() {
        return w1;
    }

    public void setW1(int w1) {
        this.w1 = w1;
    }

    public int getW2() {
        return w2;
    }

    public void setW2(int w2) {
        this.w2 = w2;
    }

    public int getW3() {
        return w3;
    }

    public void setW3(int w3) {
        this.w3 = w3;
    }

    public int getW4() {
        return w4;
    }

    public void setW4(int w4) {
        this.w4 = w4;
    }

    public int getW5() {
        return w5;
    }

    public void setW5(int w5) {
        this.w5 = w5;
    }

    public int getW6() {
        return w6;
    }

    public void setW6(int w6) {
        this.w6 = w6;
    }

    public int getW7() {
        return w7;
    }

    public void setW7(int w7) {
        this.w7 = w7;
    }

    public int getW8() {
        return w8;
    }

    public void setW8(int w) {
        this.w8 = w;
    }

    public int getW9() {
        return w9;
    }

    public void setW9(int w9) {
        this.w9 = w9;
    }

    public Boolean getStop() {
        return stop;
    }

    public void setStop(Boolean stop) {
        this.stop = stop;
    }

    public int getVitoria() {
        return vitoria;
    }

    public void setVitoria(int vitoria) {
        this.vitoria = vitoria;
    }

    public int getDerrota() {
        return derrota;
    }

    public void setDerrota(int derrota) {
        this.derrota = derrota;
    }
     
    
  
    
    
}
