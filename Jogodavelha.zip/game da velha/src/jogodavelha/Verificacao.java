package jogodavelha;

/**
 *
 * @author carva
 */
public class Verificacao {
    private Boolean V1 = false;
    private Boolean V2 = false;
    private Boolean V3 = false;
    private Boolean V4 = false;
    private Boolean V5 = false;
    private Boolean V6 = false;
    private Boolean V7 = false;
    private Boolean V8 = false;
    private Boolean V9 = false;
    
    public void getFalse(){
        if(this.V1==false){
            System.out.print("V1: ");
            System.out.println(this.V1);
        }
        if(this.V2==false){
            System.out.print("V2: ");
            System.out.println(this.V2);
        }
        if(this.V3==false){
            System.out.print("V3: ");
            System.out.println(this.V3);
        }
        if(this.V4==false){
            System.out.print("V4: ");
            System.out.println(this.V4);
        }
        if(this.V5==false){
            System.out.print("V5: ");
            System.out.println(this.V5);
        }
        if(this.V6==false){
            System.out.print("V6: ");
            System.out.println(this.V6);
        }
        if(this.V7==false){
            System.out.print("V7: ");
            System.out.println(this.V7);
        }
        if(this.V8==false){
            System.out.print("V8: ");
            System.out.println(this.V8);
        }
        if(this.V9==false){
            System.out.print("V9: ");
            System.out.println(this.V9);
        }
    }
    
    
    
    public void status(){
       System.out.println(V1);
       System.out.println(V2);
       System.out.println(V3);
       System.out.println(V4);
       System.out.println(V5);
       System.out.println(V6);
       System.out.println(V7);
       System.out.println(V8);
       System.out.println(V9);
   }
    
    public void reset(){
      this.setV1(false);
      this.setV2(false);
      this.setV3(false);
      this.setV4(false);
      this.setV5(false);
      this.setV6(false);
      this.setV7(false);
      this.setV8(false);
      this.setV9(false);
  } 
    
    public void setV(int e){
        switch(e){
            case 1:
            this.setV1(true);
            break;
            case 2:
            this.setV2(true);
            break;
            case 3:
            this.setV3(true);
            break;
            case 4:
            this.setV4(true);
            break;
            case 5:
            this.setV5(true);
            break;
            case 6:
            this.setV6(true);
            break;
            case 7:
            this.setV7(true);
            break;
            case 8:
            this.setV8(true);
            break;
            case 9:
            this.setV9(true);
            break;
            
            
            
        }
    }
    
    public Boolean getV(int r){
        if(r==1){
            return this.getV1();
        }
        else if(r==2){
            return this.getV2();
        }
        else if(r==3){
            return this.getV3();
        }
        else if(r==4){
            return this.getV4();
        }
        else if(r==5){
            return this.getV5();
        }
        else if(r==6){
            return this.getV6();
        }
        else if(r==7){
            return this.getV7();
        }
        else if(r==8){
            return this.getV8();
        }
        else if(r==9){
            return this.getV9();
        }
            
        else{
            return null;
        }
        
        
    }
    
    
    
    
    
    
    
    
    public void setV1 (Boolean V1) {
    this.V1 = V1;
}
    public void setV2 (Boolean V2) {
    this.V2 = V2;
}
    public Boolean getV1() {
        return V1;
    }
    public Boolean getV3() {
        return V3;
    }
    public void setV3(Boolean V3) {
        this.V3 = V3;
    }
    public Boolean getV4() {
        return V4;
    }
    public void setV4(Boolean V4) {
        this.V4 = V4;
    }
    public Boolean getV5() {
        return V5;
    }
    public void setV5(Boolean V5) {
        this.V5 = V5;
    }
    public Boolean getV6() {
        return V6;
    }
    public void setV6(Boolean V6) {
        this.V6 = V6;
    }
    public Boolean getV7() {
        return V7;
    }
    public void setV7(Boolean V7) {
        this.V7 = V7;
    }
    public Boolean getV8() {
        return V8;
    }
    public void setV8(Boolean V8) {
        this.V8 = V8;
    }
    public Boolean getV9() {
        return V9;
    }
    public void setV9(Boolean V9) {
        this.V9 = V9;
    }
    public Boolean getV2() {
        return V2;
    }

    
    
}

