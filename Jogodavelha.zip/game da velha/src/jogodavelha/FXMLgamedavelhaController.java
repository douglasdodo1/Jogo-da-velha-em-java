package jogodavelha;

import java.net.URL;
import java.util.Random;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.AnchorPane;
import javax.swing.JOptionPane;

/**
 *
 * @author carva
 */
public class FXMLgamedavelhaController implements Initializable {
  
    @FXML
    private Label label;  
    @FXML
    private AnchorPane principal;
    @FXML
    private Button btP1;
    @FXML
    private Button btP2;
    @FXML
    private Button btP3;
    @FXML
    private Button btP4;
    @FXML
    private Button btP5;
    @FXML
    private Button btP6;
    @FXML
    private Button btP7;
    @FXML
    private Button btP8;
    @FXML
    private Button btP9;
    @FXML
    private Label lblNome;
    @FXML
    private Label lblVitorias;
    @FXML
    private Label lblDerrotas;
     
     Verificacao v = new Verificacao();
     Boolean fj = true;
     Random aleatorio = new Random();
     Random pc = new Random();
     Boolean vs = false;
     Boolean full = false;
     Botao b = new Botao();
     Vitoria w = new Vitoria();
    
    @FXML
    private void btP1Clique(javafx.event.ActionEvent event) {   
    b.acoes(btP1, btP2, btP5, btP4, btP3, btP6, btP7, btP8, btP9, v, 1, 2, 5, 4, 3, 6,7, 8,9,lblVitorias,lblDerrotas);
} 
     
     @FXML
    private void btP2Clique(javafx.event.ActionEvent event) {
    b.acoes(btP2, btP1, btP5, btP3, btP4, btP6, btP7, btP8, btP9, v, 2, 1, 5, 3, 4, 6, 7, 8, 9,lblVitorias,lblDerrotas);
       
    }
    
     @FXML
    private void btP3Clique(javafx.event.ActionEvent event) {
     b.acoes(btP3, btP2, btP5, btP6, btP1, btP4, btP7, btP8, btP9, v, 3, 2, 5, 6, 1, 4, 7, 8, 9,lblVitorias,lblDerrotas);
    }
    
     @FXML
    private void btP4Clique(javafx.event.ActionEvent event) {
       b.acoes(btP4, btP1, btP5, btP7, btP2, btP3, btP6, btP8, btP9, v, 4, 1, 5, 7, 2, 3, 6, 8, 9,lblVitorias,lblDerrotas);
    }
    
     @FXML
    private void btP5Clique(javafx.event.ActionEvent event) {
       b.acoes(btP5, btP2, btP4, btP6, btP1, btP3, btP7, btP8, btP9, v, 5, 2, 4, 6, 1, 3, 7, 8,9,lblVitorias,lblDerrotas);
    }
    
     @FXML
    private void btP6Clique(javafx.event.ActionEvent event) {
       b.acoes(btP6, btP3, btP5, btP9, btP1, btP2, btP4, btP7, btP8, v, 6, 3, 5, 9, 1, 2, 4, 7, 8,lblVitorias,lblDerrotas);
    }
     @FXML
    private void btP7Clique(javafx.event.ActionEvent event) {
       b.acoes(btP7, btP4, btP5, btP8, btP1, btP2, btP3, btP6, btP9, v, 7, 4, 5, 8, 1, 2, 3, 6, 9,lblVitorias,lblDerrotas);
    }
     @FXML
    private void btP8Clique(javafx.event.ActionEvent event) {
      b.acoes(btP8, btP7, btP5, btP9, btP4, btP6, btP1, btP2, btP3, v, 8, 7, 5, 9, 4, 6, 1, 2, 3,lblVitorias,lblDerrotas);
    }
     @FXML
    private void btP9Clique(javafx.event.ActionEvent event) {
      b.acoes(btP9, btP8, btP5, btP6, btP1, btP2, btP3, btP7, btP4, v, 9, 8, 5, 6, 1, 2, 3, 7, 4,lblVitorias,lblDerrotas);
    }
   
    @FXML
    private void ResetClique(javafx.event.ActionEvent event) {
      b.resetar(btP1, btP2, btP3, btP4, btP5, btP6, btP7, btP8, btP9, v, 1, 2, 3, 4, 5, 6, 7, 8, 9);

    }
    
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
      b.resetar(btP1, btP2, btP3, btP4, btP5, btP6, btP7, btP8, btP9, v, 1, 2, 3, 4, 5, 6, 7, 8, 9);
      String nome = JOptionPane.showInputDialog("Informe seu nome nome");
      lblNome.setText(nome);
        
        }  
        
        
        
      
       
}    
    

