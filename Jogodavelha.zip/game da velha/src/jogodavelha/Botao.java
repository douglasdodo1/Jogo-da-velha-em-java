package jogodavelha;

import java.util.Random;
import javafx.scene.control.Button;
import javafx.scene.control.Label;

/**
 *
 * @author carva
 */
public class Botao {
    Random aleatorio = new Random();
    Boolean fj ;
    boolean full ;
    Verificacao v = new Verificacao();
    int caso = 0;
    Vitoria w = new Vitoria();
    private Boolean prej1;
    private Boolean prej2;
    private Boolean prej3;
    private Boolean prej4;
    private Boolean prej5;
    private Boolean prej6;
    private Boolean prej7;
    private Boolean prej8;
    private Boolean prej9;
   
   public void acoes(Button b1,Button b2,Button b3,Button b4,Button b5,Button b6
    ,Button b7,Button b8,Button b9,Verificacao v,int e1,int e2,int e3,int e4
    ,int e5,int e6,int e7,int e8,int e9,Label vv,Label d) {
       if(w.getLoose()==true){
          this.setFj(false);
         
       }
          
       if(this.fj==true&&v.getV(e1)==false){
            
            b1.setText("X");
            b1.setStyle("-fx-text-fill:green");
            
            this.setFj(false);
            if(w.getStop()==true){
            this.setFull(true);
        }
            else{
             this.setFull(false);
            }
            w.setWp(e1);
            v.setV(e1);
            w.getWc();
            if(w.getStop()==true){
                vv.setText(Integer.toString(w.getVitoria()));
            }
        
            if(w.getStop()==false){
            while(this.isFull()==false){
                caso = 0;
               
            if(this.getFj()==false&& v.getV(e2)==false){
                int va = aleatorio.nextInt(2);
                switch(va){
                    case 0:
                    b2.setText("X");
                    b2.setStyle("-fx-text-fill:red");
                    this.setFull(true);
                    v.setV(e2);
                    w.setWm(e2);
                    this.setFj(true);
                    caso = 0 ;
                    w.getWc();
                    if(w.getPerdeu()==true){
           d.setText(Integer.toString(w.getDerrota()));
       }
                    break;  
                    case 1:
                    caso ++;
                    break;                    
                }  
            }
            else{
                caso++;
            }

            if(this.getFj()==false&& v.getV(e3)==false&&caso==1){
                int va = aleatorio.nextInt(2);
                switch(va){
                    case 0:
                   b3.setText("X");
                   b3.setStyle("-fx-text-fill:red");
                   this.setFull(true);
                   v.setV(e3);
                   w.setWm(e3);
                   this.setFj(true);
                   caso = 0 ;
                   w.getWc();
                   if(w.getPerdeu()==true){
           d.setText(Integer.toString(w.getDerrota()));
       }
                    break;  
                    case 1:
                    caso ++;
                    break;  
                } 
            }
            else{
                caso++;
            }
            
             if(this.getFj()==false&& v.getV(e4)==false&&caso==2){
                int va = aleatorio.nextInt(2);
                switch(va){
                    case 0:
                   b4.setText("X");
                   b4.setStyle("-fx-text-fill:red");
                   this.setFull(true);
                   v.setV(e4);
                   w.setWm(e4);
                   this.setFj(true);
                   caso = 0 ;
                   w.getWc();
                   if(w.getPerdeu()==true){
           d.setText(Integer.toString(w.getDerrota()));
       }
                    break;  
                    case 1:
                    caso ++;
                    break;
            }               
        }
             else{
                caso++;
            }
            if(this.getFj()==false&& v.getV(e5)==false&&caso==3){
                int va = aleatorio.nextInt(2);
                switch(va){
                    case 0:
                   b5.setText("X");
                   b5.setStyle("-fx-text-fill:red");
                   this.setFull(true);
                   v.setV(e5);
                   w.setWm(e5);
                   this.setFj(true);
                   caso = 0 ;
                   w.getWc();
                   if(w.getPerdeu()==true){
           d.setText(Integer.toString(w.getDerrota()));
       }
                    break;  
                    case 1:
                    caso ++;
                    break; 
                }
            }
            else{
                caso++;
            }
            if(this.getFj()==false&& v.getV(e6)==false&&caso==4){
                int va = aleatorio.nextInt(4);
                switch(va){
                    case 0:
                   b6.setText("X");
                   b6.setStyle("-fx-text-fill:red");
                   this.setFull(true);
                   v.setV(e6);
                   w.setWm(e6);
                   this.setFj(true);
                   caso = 0 ;
                   w.getWc();
                   if(w.getPerdeu()==true){
           d.setText(Integer.toString(w.getDerrota()));
       }
                    break;  
                    case 1:
                    caso ++;
                    break; 
                    case 2:
                    caso ++;    
                    break;
                    case 3:
                    caso ++;
                    break;
                }
            }
            else{
                caso++;
            }
            if(this.getFj()==false&& v.getV(e7)==false&&caso==5){
                int va = aleatorio.nextInt(4);
                switch(va){
                    case 0:
                   b7.setText("X");
                   b7.setStyle("-fx-text-fill:red");
                   this.setFull(true);
                   v.setV(e7);
                   w.setWm(e7);
                   this.setFj(true);
                   caso = 0 ;
                   w.getWc();
                   if(w.getPerdeu()==true){
           d.setText(Integer.toString(w.getDerrota()));
       }
                    break;  
                    case 1:
                    caso ++;
                    break; 
                    case 2:
                    caso ++;    
                    break;
                    case 3:
                    caso ++;
                    break;
                }
            }
            else{
                caso++;
            }
            if(this.getFj()==false&& v.getV(e8)==false&&caso==6){
                int va = aleatorio.nextInt(4);
                switch(va){
                    case 0:
                   b8.setText("X");
                   b8.setStyle("-fx-text-fill:red");
                   this.setFull(true);
                   v.setV(e8);
                   w.setWm(e8);
                   this.setFj(true);
                   caso = 0 ;
                   w.getWc();
                   if(w.getPerdeu()==true){
           d.setText(Integer.toString(w.getDerrota()));
       }
                    break;  
                    case 1:
                    caso ++;
                    break; 
                    case 2:
                    caso ++;    
                    break;
                    case 3:
                    caso ++;
                    break;
                }
            }
            else{
                caso++;
            }
            if(this.getFj()==false&& v.getV(e9)==false&&caso==7){
                int va = aleatorio.nextInt(4);
                switch(va){
                    case 0:
                   b9.setText("X");
                   b9.setStyle("-fx-text-fill:red");
                   this.setFull(true);
                   v.setV(e9);
                   w.setWm(e9);
                   this.setFj(true);
                   caso = 0 ;
                   w.getWc();
                   if(w.getPerdeu()==true){
           d.setText(Integer.toString(w.getDerrota()));
       }
                    break;  
                    case 1:
                    caso ++;
                    break; 
                    case 2:
                    caso ++;    
                    break;
                    case 3:
                    caso ++;
                    break;
                }
            }
            else{
                caso++;
            }
            if(v.getV(e1)==true&&v.getV(e2)==true&&v.getV(e3)==true
              &&v.getV(e4)==true&&v.getV(e5)==true&&v.getV(e6)==true
              &&v.getV(e7)==true&&v.getV(e8)==true&&v.getV(e9)==true){
                this.setFull(true);
                caso = 0;
                if(w.getPerdeu()==true){
           d.setText(Integer.toString(w.getDerrota()));
       }
            }
             
            }
   }
       }
       
   }
   
   public void pcPlay(Button b1,Button b2,Button b3,Button b4,Button b5,Button b6
    ,Button b7,Button b8,Button b9, Verificacao v,int e1,int e2,int e3,int e4
    ,int e5,int e6,int e7,int e8,int e9){
       //int vpc = aleatorio.nextInt(9);
       while(this.isFull()==false){
           caso = 0;
           if( v.getV(e1)==false){
                System.out.println("caso: "+caso);
                int va = aleatorio.nextInt(2);
                switch(va){
                    case 0:
                    b1.setText("X");
                    b1.setStyle("-fx-text-fill:red");
                    this.setFull(true);
                    v.setV(e1);
                    w.setWm(e1);
                    caso = 0 ;
                    break;  
                    case 1:
                    caso ++;
                    break;                    
                }  
            }
            else{
                caso++;
            }
           if(v.getV(e2)==false&&caso==1){
                System.out.println("caso: "+caso);
                int va = aleatorio.nextInt(2);
                switch(va){
                    case 0:
                    b2.setText("X");
                    b2.setStyle("-fx-text-fill:red");
                    this.setFull(true);
                    v.setV(e2);
                    w.setWm(e2);
                    caso = 0 ;
                    break;  
                    case 1:
                    caso ++;
                    break;                    
                }  
            }
            else{
                caso++;
            }
           if( v.getV(e3)==false&&caso==2){
                System.out.println("caso: "+caso);
                int va = aleatorio.nextInt(2);
                switch(va){
                    case 0:
                    b3.setText("X");
                    b3.setStyle("-fx-text-fill:red");
                    this.setFull(true);
                    v.setV(e3);
                    w.setWm(e3);
                    caso = 0 ;
                    break;  
                    case 1:
                    caso ++;
                    break;                    
                }  
            }
            else{
                caso++;
            }
           if(v.getV(e4)==false&&caso==3){
                System.out.println("caso: "+caso);
                int va = aleatorio.nextInt(2);
                switch(va){
                    case 0:
                    b4.setText("X");
                    b4.setStyle("-fx-text-fill:red");
                    this.setFull(true);
                    v.setV(e4);
                    w.setWm(e4);
                    caso = 0 ;
                    break;  
                    case 1:
                    caso ++;
                    break;                    
                }  
            }
            else{
                caso++;
            }
           if(v.getV(e5)==false&&caso==4){
                System.out.println("caso: "+caso);
                int va = aleatorio.nextInt(2);
                switch(va){
                    case 0:
                    b5.setText("X");
                    b5.setStyle("-fx-text-fill:red");
                    this.setFull(true);
                    v.setV(e5);
                    w.setWm(e5);
                    caso = 0 ;
                    break;  
                    case 1:
                    caso ++;
                    break;                    
                }  
            }
            else{
                caso++;
            }
           if(v.getV(e6)==false&&caso==5){
                System.out.println("caso: "+caso);
                int va = aleatorio.nextInt(2);
                switch(va){
                    case 0:
                    b6.setText("X");
                    b6.setStyle("-fx-text-fill:red");
                    this.setFull(true);
                    v.setV(e6);
                    w.setWm(e6);
                    caso = 0 ;
                    break;  
                    case 1:
                    caso ++;
                    break;                    
                }  
            }
            else{
                caso++;
            }
           if(v.getV(e7)==false&&caso==6){
                System.out.println("caso: "+caso);
                int va = aleatorio.nextInt(2);
                switch(va){
                    case 0:
                    b7.setText("X");
                    b7.setStyle("-fx-text-fill:red");
                    this.setFull(true);
                    v.setV(e7);
                    w.setWm(e7);
                    caso = 0 ;
                    break;  
                    case 1:
                    caso ++;
                    break;                    
                }  
            }
            else{
                caso++;
            }
           if( v.getV(e8)==false&&caso==7){
                System.out.println("caso: "+caso);
                int va = aleatorio.nextInt(2);
                switch(va){
                    case 0:
                    b8.setText("X");
                    b8.setStyle("-fx-text-fill:red");
                    this.setFull(true);
                    v.setV(e8);
                    w.setWm(e8);
                    caso = 0 ;
                    break;  
                    case 1:
                    caso ++;
                    break;                    
                }  
            }
            else{
                caso++;
            }
           if(v.getV(e9)==false&&caso==8){
                System.out.println("caso: "+caso);
                int va = aleatorio.nextInt(2);
                switch(va){
                    case 0:
                    b9.setText("X");
                    b9.setStyle("-fx-text-fill:red");
                    this.setFull(true);
                    v.setV(e9);
                    w.setWm(e9);
                    caso = 0 ;
                    break;  
                    case 1:
                    caso ++;
                    break;                    
                }  
            }
            else{
                caso++;
            }
       }
   }
  
   public void resetar(Button b1,Button b2,Button b3,Button b4,Button b5,Button b6
    ,Button b7,Button b8,Button b9, Verificacao v,int e1,int e2,int e3,int e4
    ,int e5,int e6,int e7,int e8,int e9){
       w.setLoose(false);
       int va = aleatorio.nextInt(2);
       v.reset();
       w.reset();
       b1.setText(null);
       b2.setText(null);
       b3.setText(null);
       b4.setText(null);
       b5.setText(null);
       b6.setText(null);
       b7.setText(null);
       b8.setText(null);
       b9.setText(null);      
       v.status();
       w.status();
       this.setFj(true);
       this.setFull(false);
       w.setStop(false);
       if(va==0){
           
       }
       else{
        this.pcPlay(b1, b2, b3, b4, b5, b6, b7, b8, b9, v, 1, 2, 3, 4, 5, 6, 7, 8, 9);
        
    }
       
   }
   
    
    public Boolean getFj() {
        return fj;
    }

    public void setFj(Boolean fj) {
        this.fj = fj;
    }

    public boolean isFull() {
        return full;
    }

    public void setFull(boolean full) {
        this.full = full;
    }

    public Verificacao getV() {
        return v;
    }

    public void setV(Verificacao v) {
        this.v = v;
    }





    
}